// GradLink Hub JavaScript
// Contains client-side interactions for navigation, login, filtering, and slideshow.

// Navigate to another page within the site.
function goTo(page) {
    window.location.href = page;
}

// Filter available jobs by title and location on the jobs page.
function filterJobs() {
    const searchInput = document.getElementById('search').value.toLowerCase();
    const locationInput = document.getElementById('location').value.toLowerCase();
    const jobs = document.querySelectorAll('#jobs .card');

    jobs.forEach(job => {
        const title = job.getAttribute('data-title').toLowerCase();
        const location = job.getAttribute('data-location').toLowerCase();
        const matchesSearch = title.includes(searchInput);
        const matchesLocation = location.includes(locationInput);

        if (matchesSearch && matchesLocation) {
            job.style.display = 'block';
        } else {
            job.style.display = 'none';
        }
    });
}

// Apply for job
function applyJob(jobTitle) {
    alert(`Application submitted for ${jobTitle}!`);
    // In a real app, this would send data to server
}

// Enroll in a course from the skills hub.
function enroll(course) {
    alert(`Enrolled in ${course}!`);
    // In a real app, this would send data to server
}

// Login function
function login() {
    const fullName = document.getElementById('fullName')?.value.trim();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!fullName) {
        alert('Please enter your full name.');
        return;
    }

    if (email && password) {
        localStorage.setItem('gradlinkUserName', fullName);
        alert('Login successful!');
        window.location.href = 'dashboard.html';
    } else {
        alert('Please enter email and password.');
    }
}

// Load dashboard with user info and personalize the welcome message.
function loadDashboard() {
    const welcomeHeading = document.getElementById('welcomeHeading');
    const userName = localStorage.getItem('gradlinkUserName');

    if (welcomeHeading) {
        if (userName) {
            welcomeHeading.textContent = `Welcome back, ${userName}!`;
        } else {
            welcomeHeading.textContent = 'Welcome back!';
        }
    }
}

// Show message (for pro_html.html)
function showMessage() {
    alert('Welcome to GradLink Hub!');
}

function goBack() {
    window.history.back();
}

// Homepage slideshow - Professional images bridging education and employment
// A seamless rotating set of education, career, and success story images
const slides = [
    'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    'https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    'https://images.pexels.com/photos/3182806/pexels-photo-3182806.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    'https://images.pexels.com/photos/4145194/pexels-photo-4145194.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
];
let currentSlideIndex = 0;
let slideshowInterval = null;

function showSlide(index) {
    const slideImage = document.getElementById('heroSlide');
    if (!slideImage) return;
    currentSlideIndex = (index + slides.length) % slides.length;
    slideImage.style.opacity = '0';
    
    // Fade transition
    setTimeout(() => {
        slideImage.src = slides[currentSlideIndex];
        slideImage.style.opacity = '1';
    }, 300);
}

function nextSlide() {
    showSlide(currentSlideIndex + 1);
}

function prevSlide() {
    showSlide(currentSlideIndex - 1);
}

function initSlideshow() {
    const slideImage = document.getElementById('heroSlide');
    if (!slideImage) return;
    
    // Add smooth transition effect
    slideImage.style.transition = 'opacity 0.5s ease-in-out';
    slideImage.style.opacity = '1';
    
    showSlide(0);
    
    // Auto-advance slides every 5 seconds
    if (slideshowInterval) clearInterval(slideshowInterval);
    slideshowInterval = setInterval(nextSlide, 5000);
}

// Terms Modal behavior
function showTermsModal() {
    const modal = document.getElementById('termsModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function acceptTerms() {
    const modal = document.getElementById('termsModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    initSlideshow();
    showTermsModal();
});